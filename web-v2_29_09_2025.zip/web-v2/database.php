<?php

    $db_server = "sql200.infinityfree.com";
    $db_user = "if0_40044662";
    $db_password = "minh060906";
    $db_name = "if0_40044662_website";
    $conn = "";

    $conn = mysqli_connect($db_server,
                           $db_user,
                           $db_password,
                           $db_name);

    
?>